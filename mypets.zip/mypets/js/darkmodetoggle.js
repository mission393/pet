document.addEventListener("DOMContentLoaded", function () {
    const darkModeBtn = document.querySelector("[data-bs-theme-value='dark']");
    const lightModeBtn = document.querySelector("[data-bs-theme-value='light']");
    const htmlElement = document.documentElement;

    function setTheme(mode) {
        htmlElement.setAttribute("data-bs-theme", mode);
    }

    darkModeBtn.addEventListener("click", function () {
        setTheme("dark");
    });

    lightModeBtn.addEventListener("click", function () {
        setTheme("light");
    });
});


